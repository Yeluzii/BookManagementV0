create definer = root@localhost view 书籍一览 as
select `bookshop`.`goods`.`id`     AS `id`,
       `bookshop`.`goods`.`name`   AS `name`,
       `bookshop`.`goods`.`author` AS `author`,
       `bookshop`.`goods`.`isbn`   AS `isbn`
from `bookshop`.`goods`;

-- comment on column 书籍一览.name not supported: 书名

-- comment on column 书籍一览.author not supported: 作者

-- comment on column 书籍一览.isbn not supported: ISBN

